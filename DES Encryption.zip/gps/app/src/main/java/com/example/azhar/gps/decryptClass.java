package com.example.azhar.gps;

import java.util.Scanner;

/**
 * Created by Azhar on 16/12/2017.
 */
  /*
*/
public class decryptClass {

    public static String getDecrypt(String m, String key) {
        // TODO Auto-generated method stub
        Scanner in = new Scanner(System.in);
        encrypt m1 = new encrypt();
        String cipher = m;
        keyClass.returnKey(key);

        String ip__1 = m1.convertToBinary(cipher);
        String r16l16 = convertToR16L16(ip__1);
        String r16 = r16l16.substring(0, r16l16.length()/2);
        String L16 = r16l16.substring(r16l16.length()/2,r16l16.length());
        String r15 = L16;
        String L15 = m1.calculate(r16, r15, keyClass.getK16());
        String r14 = L15;
        String L14 = m1.calculate(r15, r14, keyClass.getK15());
        String r13 = L14;
        String L13 = m1.calculate(r14, r13, keyClass.getK14());
        String r12 = L13;
        String L12 = m1.calculate(r13, r12, keyClass.getK13());
        String r11 = L12;
        String L11 = m1.calculate(r12, r11, keyClass.getK12());
        String r10 = L11;
        String L10 = m1.calculate(r11, r10, keyClass.getK11());
        String r9 = L10;
        String L9 = m1.calculate(r10, r9, keyClass.getK10());
        String r8 = L9;
        String L8 = m1.calculate(r9, r8, keyClass.getK9());
        String r7 = L8;
        String L7 = m1.calculate(r8, r7, keyClass.getK8());
        String r6 = L7;
        String L6 = m1.calculate(r7, r6, keyClass.getK7());
        String r5 = L6;
        String L5 = m1.calculate(r6, r5, keyClass.getK6());
        String r4 = L5;
        String L4 = m1.calculate(r5, r4, keyClass.getK5());
        String r3 = L4;
        String L3 = m1.calculate(r4, r3, keyClass.getK4());
        String r2 = L3;
        String L2 = m1.calculate(r3, r2, keyClass.getK3());
        String r1 = L2;
        String L1 = m1.calculate(r2, r1, keyClass.getK2());
        String r0 = L1;
        String L0 = m1.calculate(r1, r0, keyClass.getK1());
        String IP = L0+r0;
        String a =  convertToPlainText(IP);
        String plainText = m1.turnToHexa(a);
        return plainText;

    }
    public static String convertToR16L16(String str){
        StringBuffer ans = new StringBuffer(str);
        int table[][] = {{20,4,24,8},{28,12,32,16},
                {19,3,23,7},{27,11,31,15},
                {18,2,22,6},{26,10,30,14},
                {17,1,21,5},{25,9,29,13}
        };
        int k=0;
        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table[i].length; j++) {
                int a = (table[i][j]) - 1;
                char ch = str.charAt(k);
                ans.setCharAt(a, ch);
                k++;
            }
        }
        return ans.toString();
    }
    public static String convertToPlainText(String str){
        StringBuffer ans = new StringBuffer(str);
        int table[][] = {{30,26,22,1,14,10,6,2},
                {32,28,24,20,16,12,8,4},
                {29,25,21,17,13,9,5,18},
                {31,27,23,19,15,11,7,3}

        };
        int k=0;
        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table[i].length; j++) {
                int a = (table[i][j]) - 1;
                char ch = str.charAt(k);
                ans.setCharAt(a, ch);
                k++;
            }
        }
        return ans.toString();
    }


}
