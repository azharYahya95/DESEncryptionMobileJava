package com.example.azhar.gps;

/**
 * Created by Azhar on 16/12/2017.
 */


public class keyClass {
    private static String k1;
    private static String k2;
    private static String k3;
    private static String k4;
    private static String k5;
    private static String k6;
    private static String k7;
    private static String k8;
    private static String k9;
    private static String k10;
    private static String k11;
    private static String k12;
    private static String k13;
    private static String k14;
    private static String k15;
    private static String k16;
    private static String k_plus;
    private static String c_0;
    private static String c_1;
    private static String c_2;
    private static String c_3;
    private static String c_4;
    private static String c_5;
    private static String c_6;
    private static String c_7;
    private static String c_8;
    private static String c_9;
    private static String c_10;
    private static String c_11;
    private static String c_12;
    private static String c_13;
    private static String c_14;
    private static String c_15;
    private static String c_16;
    private static String d_0;
    private static String d_1;
    private static String d_2;
    private static String d_3;
    private static String d_4;
    private static String d_5;
    private static String d_6;
    private static String d_7;
    private static String d_8;
    private static String d_9;
    private static String d_10;
    private static String d_11;
    private static String d_12;
    private static String d_13;
    private static String d_14;
    private static String d_15;
    private static String d_16;



    public static void returnKey(String key){
        encrypt m1 = new encrypt();
        String k = m1.convertToBinary(key);

        String k_plus = pc1(k);
        String c_0 = k_plus.substring(0, k_plus.length()/2);
        int a = c_0.length();
        c_1 = c_0.substring(1,a)+c_0.substring(0,1);
        c_2 = c_1.substring(1,a)+c_1.substring(0,1);
        c_3 = c_2.substring(2,a)+c_2.substring(0,2);
        c_4 = c_3.substring(2,a)+c_3.substring(0,2);
        c_5 = c_4.substring(2,a)+c_4.substring(0,2);
        c_6 = c_5.substring(2,a)+c_5.substring(0,2);
        c_7 = c_6.substring(2,a)+c_6.substring(0,2);
        c_8 = c_7.substring(2,a)+c_7.substring(0,2);
        c_9 = c_8.substring(1,a)+c_8.substring(0,1);
        c_10 = c_9.substring(2,a)+c_9.substring(0,2);
        c_11 = c_10.substring(2,a)+c_10.substring(0,2);
        c_12= c_11.substring(2,a)+c_11.substring(0,2);
        c_13= c_12.substring(2,a)+c_12.substring(0,2);
        c_14= c_13.substring(2,a)+c_13.substring(0,2);
        c_15= c_14.substring(2,a)+c_14.substring(0,2);
        c_16 = c_15.substring(1,a)+c_15.substring(0,1);

        d_0 = k_plus.substring(k_plus.length() / 2, k_plus.length());
        d_1 = d_0.substring(1, a) + d_0.substring(0, 1);
        d_2 = d_1.substring(1, a) + d_1.substring(0, 1);
        d_3 = d_2.substring(2, a) + d_2.substring(0, 2);
        d_4 = d_3.substring(2, a) + d_3.substring(0, 2);
        d_5 = d_4.substring(2, a) + d_4.substring(0, 2);
        d_6 = d_5.substring(2, a) + d_5.substring(0, 2);
        d_7 = d_6.substring(2, a) + d_6.substring(0, 2);
        d_8 = d_7.substring(2, a) + d_7.substring(0, 2);
        d_9 = d_8.substring(1, a) + d_8.substring(0, 1);
        d_10 = d_9.substring(2, a) + d_9.substring(0, 2);
        d_11 = d_10.substring(2, a) + d_10.substring(0, 2);
        d_12 = d_11.substring(2, a) + d_11.substring(0, 2);
        d_13 = d_12.substring(2, a) + d_12.substring(0, 2);
        d_14 = d_13.substring(2, a) + d_13.substring(0, 2);
        d_15 = d_14.substring(2, a) + d_14.substring(0, 2);
        d_16 = d_15.substring(1, a) + d_15.substring(0, 1);

        k1 = pc2(c_1+d_1);
        k2 = pc2(c_2+d_2);
        k3 = pc2(c_3+d_3);
        k4 = pc2(c_4+d_4);
        k5 = pc2(c_5+d_5);
        k6 = pc2(c_6+d_6);
        k7 = pc2(c_7+d_7);
        k8 = pc2(c_8+d_8);
        k9 = pc2(c_9+d_9);
        k10 = pc2(c_10+d_10);
        k11 = pc2(c_11+d_11);
        k12 = pc2(c_12+d_12);
        k13 = pc2(c_13+d_13);
        k14 = pc2(c_14+d_14);
        k15 = pc2(c_15+d_15);
        k16 = pc2(c_16+d_16);

    }
    public static String pc1(String k) {
        int table[][] = { {29, 22, 11, 4,6 ,17,15},
                {23,16,7,1,3,10,14},
                {2,30,9,25,26,19,13},
                {31,20,5,18,12,28,21}
        };
        String ans = "";
        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table[i].length; j++) {
                int a = (table[i][j]) - 1;
                ans += k.charAt(a);
            }
        }
        return ans;

    }
    public static String pc2(String k){
        int table[][] = {
                {11,8,23,16,13,25},
                {20,15,3,6,10,12,},
                {19,14,7,26,21,2},
                {1,5,17,4,27,24}
        };
        String ans = "";
        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table[i].length; j++) {
                int a = (table[i][j]) - 1;
                ans += k.charAt(a);
            }
            ans+=" ";
        }
        return ans;
    }

    public static String getK1() {
        return k1;
    }

    public static String getK2() {
        return k2;
    }

    public static String getK3() {
        return k3;
    }

    public static String getK4() {
        return k4;
    }

    public static String getK5() {
        return k5;
    }

    public static String getK6() {
        return k6;
    }

    public static String getK7() {
        return k7;
    }

    public static String getK8() {
        return k8;
    }

    public static String getK9() {
        return k9;
    }

    public static String getK10() {
        return k10;
    }

    public static String getK11() {
        return k11;
    }

    public static String getK12() {
        return k12;
    }

    public static String getK13() {
        return k13;
    }

    public static String getK14() {
        return k14;
    }

    public static String getK15() {
        return k15;
    }

    public static String getK16() {
        return k16;
    }
    public static String getK_plus() {return k_plus;}

    public static String getC_0() {return c_0;}

    public static String getC_1() {
        return c_1;
    }

    public static String getC_2() {
        return c_2;
    }

    public static String getC_3() {
        return c_3;
    }

    public static String getC_4() {
        return c_4;
    }

    public static String getC_5() {
        return c_5;
    }

    public static String getC_6() {
        return c_6;
    }

    public static String getC_7() {
        return c_7;
    }

    public static String getC_8() {
        return c_8;
    }

    public static String getC_9() {
        return c_9;
    }

    public static String getC_10() {
        return c_10;
    }

    public static String getC_11() {
        return c_11;
    }

    public static String getC_12() {
        return c_12;
    }

    public static String getC_13() {
        return c_13;
    }

    public static String getC_14() {
        return c_14;
    }

    public static String getC_15() {
        return c_15;
    }

    public static String getC_16() {
        return c_16;
    }

    public static String getD_0() {
        return d_0;
    }

    public static String getD_1() {
        return d_1;
    }

    public static String getD_2() {
        return d_2;
    }

    public static String getD_3() {
        return d_3;
    }

    public static String getD_4() {
        return d_4;
    }

    public static String getD_5() {
        return d_5;
    }

    public static String getD_6() {
        return d_6;
    }

    public static String getD_7() {
        return d_7;
    }

    public static String getD_8() {
        return d_8;
    }

    public static String getD_9() {
        return d_9;
    }

    public static String getD_10() {
        return d_10;
    }

    public static String getD_11() {
        return d_11;
    }

    public static String getD_12() {
        return d_12;
    }

    public static String getD_13() {
        return d_13;
    }

    public static String getD_14() {
        return d_14;
    }

    public static String getD_15() {
        return d_15;
    }

    public static String getD_16() {
        return d_16;
    }

}
