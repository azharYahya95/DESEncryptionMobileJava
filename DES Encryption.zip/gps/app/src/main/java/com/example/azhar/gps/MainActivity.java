package com.example.azhar.gps;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button enc;
    private Button dec;
    private TextView ans;
    private EditText input;
    private EditText key;
    private String a;
    private String b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        enc = (Button)findViewById(R.id.encBtn);
        dec = (Button)findViewById(R.id.decBtn);
        input = (EditText) findViewById(R.id.insertText);
        ans = (TextView)findViewById(R.id.tv);
        key = (EditText) findViewById(R.id.keyText);


        enc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 a = input.getText().toString();
                 b = key.getText().toString();
                encrypt.res(a,b);
                String answer = encrypt.result();
                ans.setText(answer);
            }
        });

        dec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a = input.getText().toString();
                b = key.getText().toString();
                String answer = decryptClass.getDecrypt(a,b);
                ans.setText(answer);

            }
        });



    }

    public  void passData(View view){
        Intent itt = new Intent(MainActivity.this,hihi.class);
        String ptData = a;
        String keyData =b;
        itt.putExtra("PtData",ptData);
        itt.putExtra("KeyData",keyData);
        startActivity(itt);
    }
}
