package com.example.azhar.gps;

/**
 * Created by Azhar on 9/12/2017.
 */
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class hihi extends AppCompatActivity {
private String data1;
private String data2;

    private boolean isDecrypt;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hihih);
        Bundle bundle = getIntent().getExtras();

         data1 = bundle.getString("PtData");
         data2 = bundle.getString("KeyData");


    }
    public void back(View view){
        Intent ttt = new Intent(hihi.this,MainActivity.class);
        startActivity(ttt);
    }
    public void oneStep(View view){
        Intent itt = new Intent(hihi.this, stepOne.class);
        String ptData = data1;
        String keyData = data2;

        itt.putExtra("PTextData",ptData);
        itt.putExtra("kData",keyData);
        startActivity(itt);
    }
    public void steptwo(View view){
        Intent itt = new Intent(hihi.this, stepTwo.class);
        String ptData = data1;
        String keyData = data2;
        itt.putExtra("PTextData",ptData);
        itt.putExtra("kData",keyData);
        startActivity(itt);
    }


}
