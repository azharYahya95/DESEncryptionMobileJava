package com.example.azhar.gps;

/**
 * Created by Azhar on 5/12/2017.
 */

/**/
public class encrypt {
    private static String z = "";

    public static  void res(String plain, String key) {
       /* Scanner in = new Scanner(System.in);
        String plain = in.next();*/
        try {
            String m = convertToBinary(plain);
            keyClass.returnKey(key);
            String IP = convertToIp(m);
            String L0 = IP.substring(0, IP.length() / 2);
            String r0 = IP.substring(IP.length() / 2, IP.length());
            String L1 = r0;
            String r1 = calculate(L0, r0, keyClass.getK1());
            String L2 = r1;
            String r2 = calculate(L1, r1, keyClass.getK2());
            String L3 = r2;
            String r3 = calculate(L2, r2, keyClass.getK3());
            String L4 = r3;
            String r4 = calculate(L3, r3, keyClass.getK4());
            String L5 = r4;
            String r5 = calculate(L4, r4, keyClass.getK5());
            String L6 = r5;
            String r6 = calculate(L5, r5, keyClass.getK6());
            String L7 = r6;
            String r7 = calculate(L6, r6, keyClass.getK7());
            String L8 = r7;
            String r8 = calculate(L7, r7, keyClass.getK8());
            String L9 = r8;
            String r9 = calculate(L8, r8, keyClass.getK9());
            String L10 = r9;
            String r10 = calculate(L9, r9, keyClass.getK10());
            String L11 = r10;
            String r11 = calculate(L10, r10, keyClass.getK11());
            String L12 = r11;
            String r12 = calculate(L11, r11, keyClass.getK12());
            String L13 = r12;
            String r13 = calculate(L12, r12, keyClass.getK13());
            String L14 = r13;
            String r14 = calculate(L13, r13, keyClass.getK14());
            String L15 = r14;
            String r15 = calculate(L14, r14, keyClass.getK15());
            String L16 = r15;
            String r16 = calculate(L15, r15, keyClass.getK16());
            String r16L16 = r16 + L16;
            String IP_minus1 = IP_min1(r16L16);
            String block[] = IP_minus1.split(" ");
            String ans = "";
            for (String c : block) {
                int q = Integer.valueOf(c, 2);
                ans += Integer.toHexString(q);
            }
            //System.out.println(ans.toUpperCase());
            z = ans.toUpperCase();



        }catch(Exception e){
            z = "Wrong in insert text or key";
        }
    }
    public static String result(){
        return z;
    }

    public static String convertToBinary(String plain) {
        String result = "";
        for (int i = 0; i < plain.length(); i++) {
            char c = plain.charAt(i);
            int curr = Integer.valueOf(c + "", 16);
            String current = Integer.toBinaryString(curr);
            while (current.length() != 4) {
                current = "0" + current;
            }

            result += (current);
        }
        return result;
    }

    public static String pc1(String k) {
        int table[][] = { { 57, 49, 41, 33, 25, 17, 9 },
                { 1, 58, 50, 42, 34, 26, 18 },
                { 10, 2, 59, 51, 43, 35, 27 },
                { 19, 11, 3, 60, 52, 44, 36 },
                { 63, 55, 47, 39, 31, 23, 15 },
                { 7, 62, 54, 46, 38, 30, 22 },
                { 14, 6, 61, 53, 45, 37, 29 },
                { 21, 13, 5, 28, 20, 12, 4 } };
        String ans = "";
        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table[i].length; j++) {
                int a = (table[i][j]) - 1;
                ans += k.charAt(a);
            }
        }
        return ans;

    }
    public static String turnKeyToHexa(String key){
        String s[] = key.split(" ");
        String newval = "";
        for(String a:s){
            newval+=a;
        }
        return encrypt.turnToHexa(newval);
    }
    public static String pc2(String k){
        int table[][] = {{14,17,11,24,1,5},
                {3,28,15,6,21,10},
                {23,19,12,4,26,8},
                {16,7,27,20,13,2},
                {41,52,31,37,47,55},
                {30,40,51,45,33,48},
                {44,49,39,56,34,53},
                {46,42,50,36,29,32}
        };
        String ans = "";
        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table[i].length; j++) {
                int a = (table[i][j]) - 1;
                ans += k.charAt(a);
            }
            ans+=" ";
        }
        return ans;
    }
    public static String convertToIp(String m){
        int table[][] = {{30,26,22,1,14,10,6,2},
                {32,28,24,20,16,12,8,4},
                {29,25,21,17,13,9,5,18},
                {31,27,23,19,15,11,7,3}
        };
        String ans = "";
        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table[i].length; j++) {
                int a = (table[i][j]) - 1;
                ans += m.charAt(a);
            }
        }
        return ans;
    }
    public static String ETable(String m){
        int table[][] = {{16,1,2,3,4,5},
                {4,5,6,7,8,9},
                {8,9,10,11,12,13},
                {12,13,14,15,16,1}
        };
        String ans = "";
        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table[i].length; j++) {
                int a = (table[i][j]) - 1;
                ans += m.charAt(a);
            }
            ans+=" ";
        }
        return ans;
    }
    public static String calculate(String L0,String r0,String k1){
        String E_r0 = ETable(r0);
        String k1_Er0 = XOR(E_r0, k1);
        String b[] = k1_Er0.split(" ");
        String s1b1 = SBox1(b[0]);
        String s2b2 = SBox2(b[1]);
        String s3b3 = SBox3(b[2]);
        String s4b4 = SBox4(b[3]);

        String snbn = s1b1+s2b2+s3b3+s4b4;
        String f_r0k1 = p(snbn);
        String r1 = XOR(L0,f_r0k1);
        return r1;
    }
    public static String XOR(String q1, String q2){
        String sum = "";
        for(int i=0;i<q2.length();i++){
            if(q1.charAt(i)!=' '){
                if(q1.charAt(i)==q2.charAt(i)){
                    sum+="0";
                }else{
                    sum+="1";
                }
            }else{
                sum+=" ";
            }
        }
        return sum;
    }
    public static String SBox1(String b1){
        int table[][] = {{14,4,13,1,2,15,11,8,3,10,6,12,5,9,0,7},
                {0,15,7,4,14,2,13,1,10,6,12,11,9,5,3,8},
                {4,1,14,8,13,6,2,11,15,12,9,7,3,10,5,0},
                {15,12,8,2,4,9,1,7,5,11,3,14,10,0,6,13}
        };
        String a = (b1.charAt(0)+"")+(b1.charAt(b1.length()-1)+"");
        String b = b1.substring(1, b1.length()-1);
        int row = Integer.valueOf(a,2);
        int col = Integer.valueOf(b,2);
        String currentr = Integer.toBinaryString(table[row][col]);
        while (currentr.length() != 4) {
            currentr = "0" + currentr;
        }
        return currentr;
    }
    public static String SBox2(String b1){
        int table[][] = {{15,1,8,14,6,11,3,4,9,7,2,13,12,0,5,10},
                {3,13,4,7,15,2,8,14,12,0,1,10,6,9,11,5},
                {0,14,7,11,10,4,13,1,5,8,12,6,9,3,2,15},
                {13,8,10,1,3,15,4,2,11,6,7,12,0,5,14,9}
        };
        String a = (b1.charAt(0)+"")+(b1.charAt(b1.length()-1)+"");
        String b = b1.substring(1, b1.length()-1);
        int row = Integer.valueOf(a,2);
        int col = Integer.valueOf(b,2);
        String currentr = Integer.toBinaryString(table[row][col]);
        while (currentr.length() != 4) {
            currentr = "0" + currentr;
        }
        return currentr;
    }
    public static String SBox3(String b1){
        int table[][] = {{10,0,9,14,6,3,15,5,1,13,12,7,11,4,2,8},
                {13,7,0,9,3,4,6,10,2,8,5,14,12,11,15,1},
                {13,6,4,9,8,15,3,0,11,1,2,12,5,10,14,7},
                {1,10,13,0,6,9,8,7,4,15,14,3,11,5,2,12}
        };
        String a = (b1.charAt(0)+"")+(b1.charAt(b1.length()-1)+"");
        String b = b1.substring(1, b1.length()-1);
        int row = Integer.valueOf(a,2);
        int col = Integer.valueOf(b,2);
        String currentr = Integer.toBinaryString(table[row][col]);
        while (currentr.length() != 4) {
            currentr = "0" + currentr;
        }
        return currentr;
    }
    public static String SBox4(String b1){
        int table[][] = {{7,13,14,3,0,6,9,10,1,2,8,5,11,12,4,15},
                {13,8,11,5,6,15,0,3,4,7,2,12,1,10,14,9},
                {10 , 6  , 9 , 0 , 12 ,11 ,  7, 13 , 15 , 1 ,  3, 14  , 5 , 2 ,  8,  4},
                {3 ,15  , 0  ,6  ,10 , 1 , 13 , 8  , 9 , 4  , 5 ,11 , 12 , 7 ,  2, 14}
        };
        String a = (b1.charAt(0)+"")+(b1.charAt(b1.length()-1)+"");
        String b = b1.substring(1, b1.length()-1);
        int row = Integer.valueOf(a,2);
        int col = Integer.valueOf(b,2);
        String currentr = Integer.toBinaryString(table[row][col]);
        while (currentr.length() != 4) {
            currentr = "0" + currentr;
        }
        return currentr;
    }
    public static String SBox5(String b1){
        int table[][] = {{2, 12 ,  4,  1,   7, 10 , 11,  6,   8,  5,   3, 15,  13,  0,14,9},
                {14, 11  , 2 ,12  , 4 , 7  ,13  ,1  , 5 , 0 , 15, 10  , 3 , 9  , 8  ,6},
                {4,2,1,11,10,13,7,8,15,9,12,5,6,3,0,14},
                {11,8,12,7,1,14,2,13,6,15,0,9,10,4,5,3}
        };
        String a = (b1.charAt(0)+"")+(b1.charAt(b1.length()-1)+"");
        String b = b1.substring(1, b1.length()-1);
        int row = Integer.valueOf(a,2);
        int col = Integer.valueOf(b,2);
        String currentr = Integer.toBinaryString(table[row][col]);
        while (currentr.length() != 4) {
            currentr = "0" + currentr;
        }
        return currentr;
    }
    public static String SBox6(String b1){
        int table[][] = {{12 , 1 , 10 ,15  , 9 , 2 ,  6  ,8  , 0, 13  , 3 , 4 , 14 , 7,   5, 11},
                {10, 15 ,  4,  2 ,  7, 12 ,  9 , 5  , 6 , 1 , 13, 14 ,  0, 11 ,  3 , 8},
                {9 ,14 , 15 , 5  , 2,  8 , 12,  3  , 7 , 0 ,  4, 10  , 1, 13 , 11 , 6},
                {4 , 3  , 2 ,12  , 9 , 5 , 15, 10 , 11 ,14  , 1 , 7 ,  6 , 0 ,  8, 13}
        };
        String a = (b1.charAt(0)+"")+(b1.charAt(b1.length()-1)+"");
        String b = b1.substring(1, b1.length()-1);
        int row = Integer.valueOf(a,2);
        int col = Integer.valueOf(b,2);
        String currentr = Integer.toBinaryString(table[row][col]);
        while (currentr.length() != 4) {
            currentr = "0" + currentr;
        }
        return currentr;
    }
    public static String SBox7(String b1){
        int table[][] = {{4, 11  , 2, 14 , 15 , 0 ,  8, 13 ,  3 ,12 ,  9,  7 ,  5, 10 ,  6 , 1},
                {13 , 0 , 11 , 7  , 4,  9  , 1 ,10 , 14 , 3 ,  5, 12 ,  2, 15 ,  8 , 6},
                {1 , 4 , 11, 13,  12 , 3  , 7, 14 , 10, 15 ,  6 , 8  , 0  ,5  , 9 , 2},
                {6, 11,  13 , 8  , 1 , 4 , 10,  7 ,  9 , 5 ,  0, 15 , 14 , 2 ,  3 ,12}
        };
        String a = (b1.charAt(0)+"")+(b1.charAt(b1.length()-1)+"");
        String b = b1.substring(1, b1.length()-1);
        int row = Integer.valueOf(a,2);
        int col = Integer.valueOf(b,2);
        String currentr = Integer.toBinaryString(table[row][col]);
        while (currentr.length() != 4) {
            currentr = "0" + currentr;
        }
        return currentr;
    }
    public static String SBox8(String b1){
        int table[][] = {{13 , 2  , 8 , 4  , 6, 15 , 11 , 1 , 10 , 9 ,  3, 14 ,  5 , 0  ,12 , 7},
                {1 ,15 , 13 , 8 , 10 , 3 ,  7 , 4 , 12,  5 ,  6, 11 ,  0, 14 ,  9 , 2},
                {7 ,11,   4 , 1  , 9 ,12 , 14 , 2  , 0 , 6 , 10, 13 , 15,  3 ,  5 , 8},
                {2 , 1 , 14 , 7 ,  4, 10 ,  8, 13 , 15 ,12  , 9 , 0 ,  3 , 5 ,  6, 11}
        };
        String a = (b1.charAt(0)+"")+(b1.charAt(b1.length()-1)+"");
        String b = b1.substring(1, b1.length()-1);
        int row = Integer.valueOf(a,2);
        int col = Integer.valueOf(b,2);
        String currentr = Integer.toBinaryString(table[row][col]);
        while (currentr.length() != 4) {
            currentr = "0" + currentr;
        }
        return currentr;
    }
    public static String p(String snbn){
        int table[][] = {{16 ,  7 , 11 ,  6},
                {13 ,  1 , 10 ,  3},
                {8 , 15 ,  2 , 14},
                {5  , 4 ,  9 , 12}


        };
        String ans = "";
        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table[i].length; j++) {
                int a = (table[i][j]) - 1;
                ans += snbn.charAt(a);
            }
        }
        return ans;
    }
    public static String IP_min1(String r16L16){
        int table[][] = {{20,4,24,8},{28,12,32,16},
                {19,3,23,7},{27,11,31,15},
                {18,2,22,6},{26,10,30,14},
                {17,1,21,5},{25,9,29,13}
        };
        String ans = "";
        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table[i].length; j++) {
                int a = (table[i][j]) - 1;
                ans += r16L16.charAt(a);
            }
            ans+=" ";
        }
        return ans;
    }
    public static String turnToHexa(String str){
        int a = 0;
        int b = a+4;
        String sum = "";
        while(a!=str.length()){
            String tem = str.substring(a, b);
            int c = Integer.valueOf(tem, 2);
            sum+=(Integer.toHexString(c));
            a=b;
            b=a+4;
        }
        return sum.toUpperCase();

    }
}

