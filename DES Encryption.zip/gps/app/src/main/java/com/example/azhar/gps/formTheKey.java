package com.example.azhar.gps;

/**
 * Created by Azhar on 10/12/2017.
 */
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class formTheKey extends AppCompatActivity{
    private String data1;
    private String data2;
    private String c_1;
    private String c_2;
    private String c_3;
    private String c_4;
    private String c_5;
    private String c_6;
    private String c_7;
    private String c_8;
    private String c_9;
    private String c_10;
    private String c_11;
    private String c_12;
    private String c_13;
    private String c_14;
    private String c_15;
    private String c_16;
    private String d_1;
    private String d_2;
    private String d_3;
    private String d_4;
    private String d_5;
    private String d_6;
    private String d_7;
    private String d_8;
    private String d_9;
    private String d_10;
    private String d_11;
    private String d_12;
    private String d_13;
    private String d_14;
    private String d_15;
    private String d_16;
    private TextView k1;
    private TextView k2;
    private TextView k3;
    private TextView k4;
    private TextView k5;
    private TextView k6;
    private TextView k7;
    private TextView k8;
    private TextView k9;
    private TextView k10;
    private TextView k11;
    private TextView k12;
    private TextView k13;
    private TextView k14;
    private TextView k15;
    private TextView k16;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.key_form);
        callValue();
        declare();
        encrypt.res(data1,data2);
        k1.setText("K1 = "+encrypt.turnKeyToHexa(encrypt.pc2(c_1+d_1)));
        k2.setText("K2 = "+encrypt.turnKeyToHexa(encrypt.pc2(c_2+d_2)));
        k3.setText("K3 = "+encrypt.turnKeyToHexa(encrypt.pc2(c_3+d_3)));
        k4.setText("K4 = "+encrypt.turnKeyToHexa(encrypt.pc2(c_4+d_4)));
        k5.setText("K5 = "+encrypt.turnKeyToHexa(encrypt.pc2(c_5+d_5)));
        k6.setText("K6 = "+encrypt.turnKeyToHexa(encrypt.pc2(c_6+d_6)));
        k7.setText("K7 = "+encrypt.turnKeyToHexa(encrypt.pc2(c_7+d_7)));
        k8.setText("K8 = "+encrypt.turnKeyToHexa(encrypt.pc2(c_8+d_8)));
        k9.setText("K9 = "+encrypt.turnKeyToHexa(encrypt.pc2(c_9+d_9)));
        k10.setText("K10 = "+encrypt.turnKeyToHexa(encrypt.pc2(c_10+d_10)));
        k11.setText("K11 = "+encrypt.turnKeyToHexa(encrypt.pc2(c_11+d_11)));
        k12.setText("K12 = "+encrypt.turnKeyToHexa(encrypt.pc2(c_12+d_12)));
        k13.setText("K13 = "+encrypt.turnKeyToHexa(encrypt.pc2(c_13+d_13)));
        k14.setText("K14 = "+encrypt.turnKeyToHexa(encrypt.pc2(c_14+d_14)));
        k15.setText("K15 = "+encrypt.turnKeyToHexa(encrypt.pc2(c_15+d_15)));
        k16.setText("K16 = "+encrypt.turnKeyToHexa(encrypt.pc2(c_16+d_16)));

    }
    public void declare(){
        k1 = (TextView)findViewById(R.id.k1);
        k2 = (TextView)findViewById(R.id.k2);
        k3 = (TextView)findViewById(R.id.k3);
        k4 = (TextView)findViewById(R.id.k4);
        k5 = (TextView)findViewById(R.id.k5);
        k6 = (TextView)findViewById(R.id.k6);
        k7 = (TextView)findViewById(R.id.k7);
        k8 = (TextView)findViewById(R.id.k8);
        k9 = (TextView)findViewById(R.id.k9);
        k10 = (TextView)findViewById(R.id.k10);
        k11 = (TextView)findViewById(R.id.k11);
        k12 = (TextView)findViewById(R.id.k12);
        k13 = (TextView)findViewById(R.id.k13);
        k14 = (TextView)findViewById(R.id.k14);
        k15 = (TextView)findViewById(R.id.k15);
        k16 = (TextView)findViewById(R.id.k16);

    }
    public void callValue(){
        Bundle bundle = getIntent().getExtras();
        c_1 = bundle.getString("c__1");
        d_1 = bundle.getString("d__1");
        c_2 = bundle.getString("c__2");
        d_2 = bundle.getString("d__2");
        c_3 = bundle.getString("c__3");
        d_3 = bundle.getString("d__3");
        c_4 = bundle.getString("c__4");
        d_4 = bundle.getString("d__4");
        c_5 = bundle.getString("c__5");
        d_5 = bundle.getString("d__5");
        c_6 = bundle.getString("c__6");
        d_6 = bundle.getString("d__6");
        c_7 = bundle.getString("c__7");
        d_7 = bundle.getString("d__7");
        c_8 = bundle.getString("c__8");
        d_8 = bundle.getString("d__8");
        c_9 = bundle.getString("c__9");
        d_9 = bundle.getString("d__9");
        c_10 = bundle.getString("c__10");
        d_10 = bundle.getString("d__10");
        c_11 = bundle.getString("c__11");
        d_11 = bundle.getString("d__11");
        c_12 = bundle.getString("c__12");
        d_12 = bundle.getString("d__12");
        c_13 = bundle.getString("c__13");
        d_13 = bundle.getString("d__13");
        c_14 = bundle.getString("c__14");
        d_14 = bundle.getString("d__14");
        c_15 = bundle.getString("c__15");
        d_15 = bundle.getString("d__15");
        c_16 = bundle.getString("c__16");
        d_16 = bundle.getString("d__16");
        data1 = bundle.getString("PtData");
        data2 = bundle.getString("keyData");

    }
}
